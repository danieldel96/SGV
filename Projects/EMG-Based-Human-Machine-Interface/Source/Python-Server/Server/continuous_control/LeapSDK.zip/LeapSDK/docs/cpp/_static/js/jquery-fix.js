// No Conflict in later (our) version of jQuery
var $jqTheme = jQuery.noConflict(true);
